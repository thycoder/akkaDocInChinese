import akka.actor.{ ActorRef, ActorSystem, Props, Actor, Inbox }
import scala.concurrent.duration._

case object Greet
case class WhoToGreet(who: String)
case class Greeting(message: String)

class Greeter extends Actor {
  var greeting = ""

  def receive = {
    case WhoToGreet(who) => greeting = s"hello, $who"
    case Greet           => sender ! Greeting(greeting) // Send the current greeting back to the sender
  }
}

/**
 * Hello Akka的Java版本
 */
object HelloAkkaScala extends App {

  // 创建 'helloakka' actor 系统
  val system = ActorSystem("helloakka")

  // 创建 'greeter' actor
  val greeter = system.actorOf(Props[Greeter], "greeter")

  // 创建一个 "盒子里的actor"
  val inbox = Inbox.create(system)

  // 让 'greeter' 修改其 'greeting' 消息
  greeter.tell(WhoToGreet("akka"), ActorRef.noSender)

  // 让 'greeter' 发回最新的 'greeting' 消息
  // 回复消息应当到达 "盒子里的actor"
  inbox.send(greeter, Greet)

  // 花 5 秒钟等待回复的 'greeting' 消息
  val Greeting(message1) = inbox.receive(5.seconds)
  println(s"Greeting: $message1")

  // 修改 greeting 消息，并且重新请求
  greeter.tell(WhoToGreet("typesafe"), ActorRef.noSender)
  inbox.send(greeter, Greet)
  val Greeting(message2) = inbox.receive(5.seconds)
  println(s"Greeting: $message2")

  val greetPrinter = system.actorOf(Props[GreetPrinter])
  // 0秒之后，每秒向greeter发送一条Greet消息，使用 GreetPrinter 作为发送者
  system.scheduler.schedule(0.seconds, 1.second, greeter, Greet)(system.dispatcher, greetPrinter)
  
}

// 打印 greeting
class GreetPrinter extends Actor {
  def receive = {
    case Greeting(message) => println(message)
  }
}