import akka.actor.ActorRef;
import akka.actor.UntypedActor;
import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.actor.Inbox;
import scala.concurrent.duration.Duration;
import scala.concurrent.duration.FiniteDuration;

import java.io.Serializable;
import java.util.concurrent.TimeUnit;

/**
 * Hello Akka的Java版本
 */
public class HelloAkkaJava {
    //定义消息类型
    /**
     * 打招呼
     */
    public static class Greet implements Serializable {}

    /**
     * 向谁打招呼
     */
    public static class WhoToGreet implements Serializable {
        public final String who;
        public WhoToGreet(String who) {
            this.who = who;
        }
    }

    /**
     * 带名字的打招呼
     */
    public static class Greeting implements Serializable {
        public final String message;
        public Greeting(String message) {
            this.message = message;
        }
    }

    /**
     * 打招呼者
     */
    public static class Greeter extends UntypedActor {
        String greeting = "";

        public void onReceive(Object message) {
            if (message instanceof WhoToGreet)
                //使用“向谁打招呼”消息中的名字，生成一条带名字的打招呼消息。
                greeting = "hello, " + ((WhoToGreet) message).who;

            else if (message instanceof Greet)
                //响应打招呼信息，回复一个带名字的打招呼信息
                getSender().tell(new Greeting(greeting), getSelf());

            //将除此之外的消息交给超类处理
            else unhandled(message);
        }
    }

    /**
     * 使用Actor的客户代码
     */
    public static void main(String[] args) {
        // 创建 'helloakka' actor系统
        final ActorSystem system = ActorSystem.create("helloakka");

        // 创建 'greeter' actor
        final ActorRef greeter = system.actorOf(Props.create(Greeter.class), "greeter");

        // 创建 "盒子里的actor"
        final Inbox inbox = Inbox.create(system);

        // 让 'greeter' 修改其 'greeting' 消息
        greeter.tell(new WhoToGreet("akka"), ActorRef.noSender());

        // 让 'greeter' 发送最新的 'greeting' 消息
        // 回复应当进入 "盒子里的actor"
        inbox.send(greeter, new Greet());

        // 花5秒钟等待 'greeting' 回复消息
        Greeting greeting1 = (Greeting) inbox.receive(Duration.create(5, TimeUnit.SECONDS));
        System.out.println("Greeting: " + greeting1.message);

        // 改变greeting消息，并且重新请求
        greeter.tell(new WhoToGreet("typesafe"), ActorRef.noSender());
        inbox.send(greeter, new Greet());
        Greeting greeting2 = (Greeting) inbox.receive(Duration.create(5, TimeUnit.SECONDS));
        System.out.println("Greeting: " + greeting2.message);

        // 0秒之后，每秒向greeter发送一条Greet消息，使用 GreetPrinter 作为发送者
        ActorRef greetPrinter = system.actorOf(Props.create(GreetPrinter.class));
        system.scheduler().schedule(Duration.Zero(), Duration.create(1, TimeUnit.SECONDS), greeter, new Greet(), system.dispatcher(), greetPrinter);
    }

    /**
     * 招呼打印者
     */
    public static class GreetPrinter extends UntypedActor {
        public void onReceive(Object message) {
            if (message instanceof Greeting)
                System.out.println(((Greeting) message).message);
        }
    }
}
