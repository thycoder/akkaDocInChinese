import scala.concurrent.duration.Duration;
import akka.actor.*;
import akka.testkit.JavaTestKit;
import akka.testkit.TestActorRef;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Hello Akka的Java版本的测试用例
 */
public class HelloAkkaTest {

    //actor系统
    static ActorSystem system;

    @BeforeClass
    public static void setup() {
        system = ActorSystem.create();
    }

    @AfterClass
    public static void teardown() {
        system.shutdown();
        system.awaitTermination(Duration.create("10 seconds"));
    }

    @Test
    /**
     * 白盒测试
     */
    public void testSetGreeter() {
        new JavaTestKit(system) {{
            //构造一个用于测试的TestActorRef，它包装了一个actor对象，可以跟普通ActorRef一样发送消息，并且可以随时取出其中的Actor对象，从而直接调用其方法和属性。
            final TestActorRef<HelloAkkaJava.Greeter> greeter =
                TestActorRef.create(system, Props.create(HelloAkkaJava.Greeter.class), "greeter1");
            //向greeter发送一个”向谁打招呼”消息
            greeter.tell(new HelloAkkaJava.WhoToGreet("testkit"), getTestActor());
            //检查actor中的greeting字段是否存放了正确的打招呼消息字符串
            Assert.assertEquals("hello, testkit", greeter.underlyingActor().greeting);
        }};
    }

    /**
     * 黑盒测试
     */
    @Test
    public void testGetGreeter() {
        new JavaTestKit(system) {{

            //构造一个真实的actor引用
            final ActorRef greeter = system.actorOf(Props.create(HelloAkkaJava.Greeter.class), "greeter2");

            //以内置的一个测试actor作为发送者，向greeter先后发送WhoToGreet和Greet消息
            greeter.tell(new HelloAkkaJava.WhoToGreet("testkit"), getTestActor());
            greeter.tell(new HelloAkkaJava.Greet(), getTestActor());

            //期望收到一条Greeting类型的消息（类似于future）
            final HelloAkkaJava.Greeting greeting = expectMsgClass(HelloAkkaJava.Greeting.class);

            //期望10秒之内收到，并且验证消息内容
            new Within(duration("10 seconds")) {
                protected void run() {
                    Assert.assertEquals("hello, testkit", greeting.message);
                }
            };
        }};
    }
}
